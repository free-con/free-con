@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0kur-windows.ps1"
pause
